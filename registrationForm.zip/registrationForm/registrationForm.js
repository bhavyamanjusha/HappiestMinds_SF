import { LightningElement } from 'lwc';



export default class RegistrationForm extends LightningElement {

    
   arr={};
   fname='';
   lname='';
   email='';
   country='';
   phone='';

    handleSubmit(){
        event.preventDefault();
        const x = this.getData();
        this.insertData(x);
        this.resetPage();
}

    getData(){
        const arr={};
        arr["fname"]= this.template.querySelector(".fname").value;
        arr["lname"]= this.template.querySelector(".lname").value;
        arr["email"]= this.template.querySelector(".email").value;
        arr["country"]= this.template.querySelector(".country").value;
        arr["phone"] = this.template.querySelector(".phone").value;
        console.log(arr.fname);
        return arr;
        

        
    }

    //To insert data and check for country code and country displaying hidden input (other country name)
    insertData(element){
        console.log("inserting..." + element.fname);
        let table_class_name = this.template.querySelector(".mytable");
        let tr =table_class_name.insertRow(table_class_name.length);
        let td1 = tr.insertCell(0);
        let td2 = tr.insertCell(1);
        let td3 = tr.insertCell(2);
        let td4 = tr.insertCell(3);
        let td5 = tr.insertCell(4);
        let td6 = tr.insertCell(5);
        // let td7 = tr.insertCell(6);
        td1.innerHTML = table_class_name.rows.length-1;
        td2.innerHTML = element.fname;
        td3.innerHTML = element.lname;
        td4.innerHTML = element.email;
        td5.innerHTML = element.country;
        
        if(element.country==='India'){
            td6.innerHTML="+91"+element.phone;
        }
        if(element.country==='USA'){
            td6.innerHTML="+1"+element.phone;
        }
        if(element.country==='Japan'){
            td6.innerHTML="+88"+element.phone;
        }
        if(element.country==='Australia'){
            td6.innerHTML="+11"+element.phone;
        }
        if(element.country==='Canada'){
            td6.innerHTML="+71"+element.phone;
        }
        else if(element.country==='Other'){
            td5.innerHTML=this.template.querySelector(".hidden").value;
            td6.innerHTML=element.phone;
        }


        // td7.innerHTML='<input type="radio" class="editbutton" value="E">';

        // if(td7){
        //     console.log("hey")
        // }
        // else{
        //     console.log("okay")
        // }

        // console.log(this.template.querySelector(".editbutton").value + "EditButton got")
        //td6.innerHTML = element.phone;
        // td7.innerHTML= `<input type="radio"> ; 
        // for(const i=1 ;i<table_class_name.rows.length;i++){
        //                 table_class_name.rows[i].onclick = function()
        //                 {
        //                 this.index=this.rowIndex;
        //                 console.log("Index");
        //                 console.log(this.index); 
        //                 console.log("Selection of "+ element.fname)
        //                 this.template.querySelector(".fname").value =this.cells[1].innerHTML;
        //                 this.template.querySelector(".lname").value = this.cells[2].innerHTML;
        //                 this.template.querySelector(".email").value = this.cells[3].innerHTML;
        //                 this.template.querySelector(".country").value = this.cells[4].innerHTML;
        //                 this.template.querySelector(".phone").value =this.cells[5].innerHTML;
        //                 table_class_name.rows[index].cells[1].innerHTML = this.template.querySelector(".fname").value;
        //     table_class_name.rows[index].cells[2].innerHTML = this.template.querySelector(".lname").value;
        //     table_class_name.rows[index].cells[3].innerHTML = this.template.querySelector(".email").value;
        //     table_class_name.rows[index].cells[4].innerHTML = this.template.querySelector(".country").value;
        //     table_class_name.rows[index].cells[5].innerHTML = this.template.querySelector(".phone").value;
//     }
                    // };
        console.log(this.phone);
        console.log(this.country);
        console.log("Inserted");
    }
    edittable(){
        let x = this.template.querySelector(".mytable");
        this.x.style.contenteditable="true";
        
    }

    saveedit(){
        let y = this.template.querySelector(".mytable");
       this.y.style.contenteditable="false";
    }

//     editRow(){
//         for(const i=1 ;i<table_class_name.rows.length;i++){
//             table_class_name.rows[i].onclick = function()
//             {
//             index=this.rowIndex;
//             console.log("Index");
//             console.log(index); 
//             this.template.querySelector(".fname").value =this.cells[1].innerHTML;
//             this.template.querySelector(".lname").value = this.cells[2].innerHTML;
//             this.template.querySelector(".email").value = this.cells[3].innerHTML;
//             this.template.querySelector(".country").value = this.cells[4].innerHTML;
//             this.template.querySelector(".phone").value =this.cells[5].innerHTML;
//         };
//             table_class_name.rows[index].cells[1].innerHTML = this.template.querySelector(".fname").value;
//             table_class_name.rows[index].cells[2].innerHTML = this.template.querySelector(".lname").value;
//             table_class_name.rows[index].cells[3].innerHTML = this.template.querySelector(".email").value;
//             table_class_name.rows[index].cells[4].innerHTML = this.template.querySelector(".country").value;
//             table_class_name.rows[index].cells[5].innerHTML = this.template.querySelector(".phone").value;
//     }
// }

    editTableDisplay(){
        this.template.querySelector(".editTable").setAttribute('style', 'display: block;')
    }

    resetPage(){
        this.template.querySelector(".fname").value = " ";
        this.template.querySelector(".lname").value = " ";
        this.template.querySelector(".email").value = " ";
        this.template.querySelector(".country").value = " ";
        this.template.querySelector(".phone").value = " ";
        console.log("The page has been reset")
    }
    
    editValue(){
    const selectedValue = this.template.querySelector(".hey");
    console.log(selectedValue+ "Entered");

    }
   
    changeVisibility(event){ 
        console.log("Entering Phone Number")    
        if(event.target.value==='Other'){           
            this.template.querySelector(".hidden").style.visibility="visible";
    }
        else{
            this.template.querySelector(".hidden").style.visibility="hidden";
    }
    console.log("Entered");

    }

    // showPhoneCode(event){
    //     console.log("done okayy");
    //     var  phoneNumber = this.template.querySelector(".phone").value;
    //     country=this.template.querySelector(".country").value;
    //     const hiddenInputValue = this.template.querySelector(".hidden").value;   
    //     this.phone.concat(this.template.querySelector(".phone").value);
    //     console.log(this.country);
    //     if(this.country.equals("India")){
    //         console.log(this.country);
    //         this.phone="=91"+event.target.value;
          
    //     }


    selectedRow(){
        let index;
        let table_class_name = this.template.querySelector(".mytable");
        console.log("Entered toggle");
        for(const i=1 ;i<table_class_name.rows.length;i++){
            table_class_name.rows[i].onclick = function()
            {
            index=this.rowIndex;

            this.classList.toggle("selected");
            console.log(index); 
        };
    }
}
 


    Validate(){
        console.log("Invalid Data");
        let errors =[];
        const errormessage = this.template.querySelector(".danger").value;
        const alphabet = /^[A-Za-z]+$/;
        fname = this.template.querySelector(".fname").value;
        lname = this.template.querySelector(".lname").value;
        email = this.template.querySelector(".email").value;
        country = this.template.querySelector(".country").value;
        phone = this.template.querySelector(".phone").value;

        if(this.fname.match(alphabet)&&(this.lname.match(alphabet))){
            return true;
        }
        if(this.fname==" "){
            this.template.querySelector(".row").innerHTML="This field cannot be empty";
        }
        else{
            this.template.querySelector(".danger").style.visibility="visible";
            console.log(errormessage);
            console.log("hey");
        
            return false;
        }

        
    }
}
    



